var contactForm = document.getElementById("contact-form")
contactForm.addEventListener("click", function() {
    alert("Формата за обратна връзка е в разработка!")
})
